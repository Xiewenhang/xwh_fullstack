- stylus 是css的预编译器
 stylus -w *.stylus -o *.css
 我们编写的stylu文件，是css的超集简写
 {:;}这些，编译成为css
 -w 表示监听文件的改变
 -o output 生成输出
- 省去了；；
- tab 缩进自动补全css选择器的前缀